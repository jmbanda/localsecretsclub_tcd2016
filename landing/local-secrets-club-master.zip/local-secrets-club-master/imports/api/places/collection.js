import {Meteor} from 'meteor/meteor';

export const Places = new Meteor.Collection('places');
